

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Employees</h1>

    <!-- Success message -->
    <div id="success-message" class="alert alert-success" style="display: none;"></div>

    <form id="employeeForm" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <input type="text" name="name" id="name" class="form-control" placeholder="Enter Name" required>
        </div>
        <div class="mb-3">
            <input type="file" name="image" id="image" class="form-control">
        </div>
        <div class="mb-3">
            <input type="date" name="join_date" id="join_date" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Employee</button>
    </form>

    <h2 class="mt-4">Employee List</h2>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>Name</th>
                <th>Image</th>
                <th>Join Date</th>
            </tr>
        </thead>
        <tbody id="employeeTable">
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($employee->name); ?></td>
                    <td>
                        <?php if($employee->image): ?>
                            <img src="<?php echo e(asset('storage/'.$employee->image)); ?>" width="50">
                        <?php else: ?>
                            No Image
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($employee->join_date); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- jQuery and AJAX Script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#employeeForm').submit(function (e) {
            e.preventDefault();

            let formData = new FormData(this);

            $.ajax({
                url: "<?php echo e(route('employees.store')); ?>",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        $('#success-message').text(response.success).show();
                        let employee = response.employee;
                        let imageHtml = employee.image ? '<img src="<?php echo e(asset('storage')); ?>/' + employee.image + '" width="50">' : 'No Image';
                        $('#employeeTable').append(
                            `<tr>
                                <td>${employee.name}</td>
                                <td>${imageHtml}</td>
                                <td>${employee.join_date}</td>
                            </tr>`
                        );
                        $('#employeeForm')[0].reset();
                    }
                },
                error: function (response) {
                    alert('Error adding employee');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employees.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\EmployeeManagementSystem\resources\views/employees/create2.blade.php ENDPATH**/ ?>