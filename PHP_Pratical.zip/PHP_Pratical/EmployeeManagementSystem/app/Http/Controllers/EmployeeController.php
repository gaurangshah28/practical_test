<?PHP
namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use Carbon\Carbon;

class EmployeeController extends Controller
{
    public function index()
    {
        return view('employees.index');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'fname' => 'required|string|max:255',
            'lname' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'join_date' => 'required|date',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $imagePath = $request->file('image') ? $request->file('image')->store('employees', 'public') : null;
       
        // Generate EMP Code (EMP-0001, EMP-0002)
        $lastEmployee = Employee::latest('id')->first();
        $newId = $lastEmployee ? $lastEmployee->id + 1 : 1;
        $empCode = 'EMP-' . str_pad($newId, 4, '0', STR_PAD_LEFT); // EMP-0001, EMP-0002


        Employee::create([
            'employee_code' => $empCode,
            'first_name' => $request->fname,
            'last_name' => $request->lname,
            'image' => $imagePath,
            'join_date' => $request->join_date,
        ]);

        return response()->json(['success' => 'Employee added successfully']);
    }

    public function getData(Request $request)
    {
        $query = Employee::query();
       
    // Apply Date Filter
    if (!empty($request->start_date) && !empty($request->end_date)) {
        $query->whereBetween('join_date', [$request->start_date, $request->end_date]);
    }
    // Apply Search Filter
    if (!empty($request->search['value'])) {
        $search = $request->search['value'];
        $query->where(function ($query) use ($search) {
            $query->where('first_name', 'LIKE', "%{$search}%")
                ->orWhere('last_name', 'LIKE', "%{$search}%");
        });
    }
    return   DataTables::of($query)
        ->addColumn('full_name', function ($employee) {
            return $employee->first_name . ' ' . $employee->last_name;
        })
        ->addColumn('joining_date', function ($employee) {
            return Carbon::parse($employee->join_date)->format('d-m-Y'); 
        })
        ->addColumn('image', function ($employee) {
            return $employee->image ? '<img src="' . asset('storage/' . $employee->image) . '" width="50">' : 'No Image';
        })    
        ->orderColumn('first_name', function ($query, $order) {
            $query->orderBy('employees.first_name', $order);
        })
        ->rawColumns(['image'])
        ->make(true);
     
    }
}
?>