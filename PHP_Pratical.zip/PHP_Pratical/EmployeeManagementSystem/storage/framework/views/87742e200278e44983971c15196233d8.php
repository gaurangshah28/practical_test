

<?php $__env->startSection('content'); ?>
    <!-- Success Message -->
    <div id="success-message" class="alert alert-success" style="display: none;"></div>
    <h3 class="mb-4">Add Employees</h3>
    <form id="employeeForm" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="col-6 mb-3">
            <input type="text" name="fname" id="fname" class="form-control" placeholder="Enter First Name" required>
        </div>
        <div class="col-6 mb-3">
            <input type="text" name="lname" id="fname" class="form-control" placeholder="Enter Last Name" required>
        </div>
        <div class="col-6 mb-3">
            <input type="file" name="image" id="image" class="form-control">
        </div>
        <div class="col-6 mb-3">
            <input type="date" name="join_date" id="join_date" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Employee</button>
    </form>

    <h3 class="mt-4">Employee List</h3>
    <div class="row mb-3">
        <div class="col-md-4">
            <input type="date" id="start_date" class="form-control" placeholder="Start Date">
        </div>
        <div class="col-md-4">
            <input type="date" id="end_date" class="form-control" placeholder="End Date">
        </div>
        <div class="col-md-4">
            <button id="filterBtn" class="btn btn-success">Filter</button>
            <button id="clearBtn" class="btn btn-danger">Clear</button>
        </div>
    </div>

    <table id="employeeTable" class="table table-bordered">
        <thead>
            <tr>
                <th>Employee Code</th>
                <th>Name</th>
                <th>Join Date</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <!-- Data will be populated by DataTables via AJAX -->
        </tbody>
    </table>

<!-- jQuery and DataTables Script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function () {
        let table = $('#employeeTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(route('employees.data')); ?>",
                data: function (d) {
                    d.start_date = $('#start_date').val();
                    d.end_date = $('#end_date').val();
                }
            },
            columns: [
                { data: 'employee_code', name: 'employee_code' },
                { data: 'full_name', name: 'full_name' },
                { data: 'joining_date', name: 'joining_date' },
                { data: 'image', name: 'image', orderable: false, searchable: false },
            ]
        });

        $('#filterBtn').click(function () {
            table.ajax.reload();
        });
        $('#clearBtn').click(function () {
        $('#start_date').val(''); // Clear Start Date
        $('#end_date').val('');   // Clear End Date
        table.ajax.reload();      // Reload DataTable with All Data
    });

        $('#employeeForm').submit(function (e) {
            e.preventDefault();
            let formData = new FormData(this);

            $.ajax({
                url: "<?php echo e(route('employees.store')); ?>",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    $('#success-message').text(response.success).show();
                    table.ajax.reload();
                    $('#employeeForm')[0].reset();
                },
                error: function () {
                    alert('Error adding employee');
                }
            });
        });
    });
   
    

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employees.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\EmployeeManagementSystem\resources\views/employees/index.blade.php ENDPATH**/ ?>