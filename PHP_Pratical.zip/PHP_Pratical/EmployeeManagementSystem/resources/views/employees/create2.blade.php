@extends('employees.layouts')

@section('content')
<div class="container">
    <h1 class="mb-4">Employees</h1>

    <!-- Success message -->
    <div id="success-message" class="alert alert-success" style="display: none;"></div>

    <form id="employeeForm" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <input type="text" name="name" id="name" class="form-control" placeholder="Enter Name" required>
        </div>
        <div class="mb-3">
            <input type="file" name="image" id="image" class="form-control">
        </div>
        <div class="mb-3">
            <input type="date" name="join_date" id="join_date" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Employee</button>
    </form>

    <h2 class="mt-4">Employee List</h2>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>Name</th>
                <th>Image</th>
                <th>Join Date</th>
            </tr>
        </thead>
        <tbody id="employeeTable">
            @foreach($employees as $employee)
                <tr>
                    <td>{{ $employee->name }}</td>
                    <td>
                        @if($employee->image)
                            <img src="{{ asset('storage/'.$employee->image) }}" width="50">
                        @else
                            No Image
                        @endif
                    </td>
                    <td>{{ $employee->join_date }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

<!-- jQuery and AJAX Script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#employeeForm').submit(function (e) {
            e.preventDefault();

            let formData = new FormData(this);

            $.ajax({
                url: "{{ route('employees.store') }}",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        $('#success-message').text(response.success).show();
                        let employee = response.employee;
                        let imageHtml = employee.image ? '<img src="{{ asset('storage') }}/' + employee.image + '" width="50">' : 'No Image';
                        $('#employeeTable').append(
                            `<tr>
                                <td>${employee.name}</td>
                                <td>${imageHtml}</td>
                                <td>${employee.join_date}</td>
                            </tr>`
                        );
                        $('#employeeForm')[0].reset();
                    }
                },
                error: function (response) {
                    alert('Error adding employee');
                }
            });
        });
    });
</script>
@endsection
