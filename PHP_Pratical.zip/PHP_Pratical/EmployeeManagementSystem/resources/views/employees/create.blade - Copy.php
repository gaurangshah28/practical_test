@extends('employees.layouts')

@section('content')

<div class="row justify-content-center mt-3">
    <div class="col-md-8">

        <div class="card">
            <div class="card-header">
                <div class="float-start">
                    Add New Employee
                </div>
            </div>
            <div class="card-body">
                <form name="employee_form" method="post" enctype="multipart/form-data">
                    @csrf

                    <div class="mb-3 row">
                        <label for="first_name" class="col-md-4 col-form-label text-md-end text-start">First Name</label>
                        <div class="col-md-6">
                          <input type="text" class="form-control @error('first_name') is-invalid @enderror" id="first_name" name="first_name" value="{{ old('first_name') }}">
                            @if ($errors->has('first_name'))
                                <span class="text-danger">{{ $errors->first('first_name') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="last_name" class="col-md-4 col-form-label text-md-end text-start">Last Name</label>
                        <div class="col-md-6">
                          <input type="text" class="form-control @error('last_name') is-invalid @enderror" id="last_name" name="last_name" value="{{ old('last_name') }}">
                            @if ($errors->has('last_name'))
                                <span class="text-danger">{{ $errors->first('last_name') }}</span>
                            @endif
                        </div>
                    </div>

                    <div class="mb-3 row">
                        <label for="join_date" class="col-md-4 col-form-label text-md-end text-start">Join Date</label>
                        <div class="col-md-6">
                        <input type="date" class="form-control @error('join_date') is-invalid @enderror"  id="join_date" name="join_date" required>
                            @if ($errors->has('join_date'))
                                <span class="text-danger">{{ $errors->first('join_date') }}</span>
                            @endif
                        </div>
                    </div>

                    <div class="mb-3 row">
                        <label for="image" class="col-md-4 col-form-label text-md-end text-start">Image</label>
                        <div class="col-md-6">
                        <input type="file" class="form-control" name="emp_image" >
                        </div>
                    </div>
                    
                    <div class="mb-3 row">
                        <input type="submit" class="col-md-3 offset-md-5 btn btn-primary" value="Save">
                    </div>
                    
                </form>
                <h2 class="mt-4">Employee List</h2>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>Name</th>
                <th>Image</th>
                <th>Join Date</th>
            </tr>
        </thead>
        <tbody id="employeeTable">
            @foreach($employees as $employee)
                <tr>
                    <td>{{ $employee->name }}</td>
                    <td>
                        @if($employee->image)
                            <img src="{{ asset('storage/'.$employee->image) }}" width="50">
                        @else
                            No Image
                        @endif
                    </td>
                    <td>{{ $employee->join_date }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
            </div>
        </div>
    </div>    
</div>
<script>
    $(document).ready(function () {
        $('#employeeForm').submit(function (e) {
            e.preventDefault();

            let formData = new FormData(this);

            $.ajax({
                url: "{{ route('save_employee') }}",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        $('#success-message').text(response.success).show();
                        let employee = response.employee;
                        let imageHtml = employee.image ? '<img src="{{ asset('storage') }}/' + employee.image + '" width="50">' : 'No Image';
                        $('#employeeTable').append(
                            `<tr>
                                <td>${employee.name}</td>
                                <td>${imageHtml}</td>
                                <td>${employee.join_date}</td>
                            </tr>`
                        );
                        $('#employeeForm')[0].reset();
                    }
                },
                error: function (response) {
                    alert('Error adding employee');
                }
            });
        });
    });
</script>

@endsection